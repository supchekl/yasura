#!/usr/bin/env bash
# Сборка Yasura (ARK-4 для PSP-E1000) на Ubuntu 24.04
set -e
sudo apt-get install -y p7zip-full genisoimage python3-pycryptodome python3-ecdsa zlib1g-dev libmpfr-dev build-essential git curl
git clone https://github.com/PSP-Archive/ARK-4 && cd ARK-4
git checkout 7c03c37
git submodule update --init --depth 1
git am ../yasura-e1000.patch   # 7 коммитов: настройки E1000, тема Liquid Glass, доработки лаунчера, подсказки, домашний экран как на iPhone, Фото, Видео, обои, сон и пункт управления, анимации, поиск и уведомления
sudo 7z x -y -o/usr/local contrib/PC/PSPSDK/pspdev.7z && sudo chown -R "$USER" /usr/local/pspdev
sudo ln -sf /usr/lib/x86_64-linux-gnu/libmpfr.so.6 /usr/lib/x86_64-linux-gnu/libmpfr.so.4
export PSPDEV=/usr/local/pspdev PATH=/usr/local/pspdev/bin:$PATH
( cd .. && git clone https://github.com/swarzesherz/sign_np.git && sed -i 's/o64/o/' sign_np/sign_np.c && make -C sign_np && mv sign_np/sign_np $PSPDEV/bin/ )
( cd .. && curl -sSLO https://github.com/Lameguy64/mkpsxiso/releases/download/v2.03/mkpsxiso-2.03-Linux.deb && sudo apt-get install -y ./mkpsxiso-2.03-Linux.deb )
make
echo "Готово: файлы в ARK-4/dist"
